/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package For_AllBean;

import java.util.LinkedList;

/**
 *
 * @author ACER
 */
public class Bean_RegistAccount {

    private LinkedList<Bean_Account001> daftar;

    public Bean_RegistAccount() {
    }

    public LinkedList<Bean_Account001> getDaftar() {
        return daftar;
    }

    public void setDaftar(LinkedList<Bean_Account001> daftar) {
        this.daftar = daftar;
    }

}
