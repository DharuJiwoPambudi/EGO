/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package For_AllBean;

/**
 *
 * @author ACER
 */
public class Bean_JasaFish {

    String nama, timeo, lokasi, keterangan, jenis, idjasa;
    

    public String getJenis() {
        return jenis;
    }

    public void setJenis(String jenis) {
        this.jenis = jenis;
    }

    public String getKeterangan() {
        return keterangan;
    }

    public void setKeterangan(String keterangan) {
        this.keterangan = keterangan;
    }

    public String getIdjasa() {
        return idjasa;
    }

    public void setIdjasa(String idjasa) {
        this.idjasa = idjasa;
    }
    Double harga;

    public Bean_JasaFish() {
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getTimeo() {
        return timeo;
    }

    public void setTimeo(String timeo) {
        this.timeo = timeo;
    }

    public String getLokasi() {
        return lokasi;
    }

    public void setLokasi(String lokasi) {
        this.lokasi = lokasi;
    }

    public String getHome() {
        return keterangan;
    }

    public void setHome(String keterangan) {
        this.keterangan = keterangan;
    }

    public Double getHarga() {
        return harga;
    }

    public void setHarga(Double harga) {
        this.harga = harga;
    }

}
