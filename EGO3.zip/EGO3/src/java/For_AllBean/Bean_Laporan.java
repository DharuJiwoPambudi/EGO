/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package For_AllBean;

/**
 *
 * @author ACER
 */
public class Bean_Laporan {

    String idjasa, konsumen, tanggal, alamat, pembayaran;
    double harga;

    public Bean_Laporan() {
    }

    public String getIdjasa() {
        return idjasa;
    }

    public void setIdjasa(String idjasa) {
        this.idjasa = idjasa;
    }

    public String getKonsumen() {
        return konsumen;
    }

    public void setKonsumen(String konsumen) {
        this.konsumen = konsumen;
    }

    public String getTanggal() {
        return tanggal;
    }

    public void setTanggal(String tanggal) {
        this.tanggal = tanggal;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }


    public String getPembayaran() {
        return pembayaran;
    }

    public void setPembayaran(String pembayaran) {
        this.pembayaran = pembayaran;
    }

    public double getHarga() {
        return harga;
    }

    public void setHarga(double harga) {
        this.harga = harga;
    }

}
