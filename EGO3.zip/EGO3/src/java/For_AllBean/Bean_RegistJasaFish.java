
package For_AllBean;

import java.util.LinkedList;

/**
 *
 * @author ACER
 */
public class Bean_RegistJasaFish {

    private LinkedList<Bean_JasaFish> resgist;

    public Bean_RegistJasaFish() {
    }

    public LinkedList<Bean_JasaFish> getResgist() {
        return resgist;
    }

    public void setResgist(LinkedList<Bean_JasaFish> resgist) {
        this.resgist = resgist;
    }

}
